var searchData=
[
  ['zep_5fdst_5fip_5faddr',['zep_dst_ip_addr',['../structzepif__init.html#a851efb99a973348f1064a31b97ce779d',1,'zepif_init']]],
  ['zep_5fdst_5fudp_5fport',['zep_dst_udp_port',['../structzepif__init.html#a86c6229ed3010158e601666afe91a286',1,'zepif_init']]],
  ['zep_5fnetif',['zep_netif',['../structzepif__init.html#a3d97bf90b6bd4dd8258a3b1caf7890e3',1,'zepif_init']]],
  ['zep_5fsrc_5fip_5faddr',['zep_src_ip_addr',['../structzepif__init.html#adbe989f1f5cba623d742187def36f02c',1,'zepif_init']]],
  ['zep_5fsrc_5fudp_5fport',['zep_src_udp_port',['../structzepif__init.html#ad739032585841b126b4c0eab5899d40f',1,'zepif_init']]]
];
