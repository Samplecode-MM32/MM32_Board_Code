var searchData=
[
  ['jl',['jl',['../structapi__msg.html#a6387bddb309c218ac0ccc5ef6d7a033e',1,'api_msg']]],
  ['jumpers',['jumpers',['../structnetbios__answer.html#a69cd3e8b8265531a7ce3e5cbd4911683',1,'netbios_answer']]]
];
