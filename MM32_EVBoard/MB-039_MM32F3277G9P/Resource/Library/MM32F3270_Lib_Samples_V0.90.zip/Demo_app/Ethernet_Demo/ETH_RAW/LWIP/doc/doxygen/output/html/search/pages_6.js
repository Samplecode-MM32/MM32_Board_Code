var searchData=
[
  ['system_20initalization',['System initalization',['../sys_init.html',1,'']]]
];
