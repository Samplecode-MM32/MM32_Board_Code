var group__sys__prot =
[
    [ "SYS_ARCH_DECL_PROTECT", "group__sys__prot.html#ga945395fa326214fc9736487242710a90", null ],
    [ "SYS_ARCH_PROTECT", "group__sys__prot.html#ga3d0e48feafd378e9c26c64567ecd8bab", null ],
    [ "SYS_ARCH_UNPROTECT", "group__sys__prot.html#ga2f48e97047945642ddeb27e65bf4ffe2", null ]
];