var group__autoip =
[
    [ "autoip_set_struct", "group__autoip.html#ga2122c0b2518b371559fef5ec1d2aed90", null ],
    [ "autoip_start", "group__autoip.html#ga1461f5826ebefc050e0d63013818d1e8", null ],
    [ "autoip_stop", "group__autoip.html#ga58a4dce658dd1263e84eb982f62587d4", null ]
];