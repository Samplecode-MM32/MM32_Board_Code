var prot_2dns_8h =
[
    [ "dns_hdr", "structdns__hdr.html", null ],
    [ "DNS_MQUERY_PORT", "prot_2dns_8h.html#a62d67af5ac6c6b3f98a6566a42564276", null ],
    [ "DNS_SERVER_PORT", "prot_2dns_8h.html#a9266b48706648ecf0625a3e651095317", null ]
];