var searchData=
[
  ['bridgeif_5finitdata_5ft',['bridgeif_initdata_t',['../group__bridgeif.html#gac47f8ce66bc6dad5dd9829467f93a1bb',1,'bridgeif.h']]]
];
