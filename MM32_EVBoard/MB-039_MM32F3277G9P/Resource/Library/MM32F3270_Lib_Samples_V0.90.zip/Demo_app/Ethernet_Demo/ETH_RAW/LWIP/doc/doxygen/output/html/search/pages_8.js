var searchData=
[
  ['zero_2dcopy_20rx',['Zero-copy RX',['../zerocopyrx.html',1,'']]]
];
