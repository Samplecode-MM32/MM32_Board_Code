var searchData=
[
  ['dns_5ffound_5fcallback',['dns_found_callback',['../dns_8h.html#ab5a9dec5b22802f91876c53e99f427ae',1,'dns.h']]]
];
