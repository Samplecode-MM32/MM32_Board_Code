var group__lwip__opts__thread =
[
    [ "DEFAULT_ACCEPTMBOX_SIZE", "group__lwip__opts__thread.html#ga5d5a6e04abe2ec233c7acdb09f992461", null ],
    [ "DEFAULT_RAW_RECVMBOX_SIZE", "group__lwip__opts__thread.html#ga4ef8f046c957750056131310a1580df7", null ],
    [ "DEFAULT_TCP_RECVMBOX_SIZE", "group__lwip__opts__thread.html#ga1bd172938b9c8ba63156fcafc87e83c7", null ],
    [ "DEFAULT_THREAD_NAME", "group__lwip__opts__thread.html#gaca13123a5c8271558353e04123957616", null ],
    [ "DEFAULT_THREAD_PRIO", "group__lwip__opts__thread.html#ga3d8715b1fdd0449d6c214e4a40108456", null ],
    [ "DEFAULT_THREAD_STACKSIZE", "group__lwip__opts__thread.html#ga7f93dfeaed4021061959f822def602cb", null ],
    [ "DEFAULT_UDP_RECVMBOX_SIZE", "group__lwip__opts__thread.html#ga09fe785559b3f0cf108da4440489e335", null ],
    [ "LWIP_TCPIP_THREAD_ALIVE", "group__lwip__opts__thread.html#ga8b99d75d9e0a0868567d10c8522915bb", null ],
    [ "SLIPIF_THREAD_NAME", "group__lwip__opts__thread.html#gae9cd260c56472324a2f0ee5f9597a675", null ],
    [ "SLIPIF_THREAD_PRIO", "group__lwip__opts__thread.html#gab1b9fc2efcbf1f804bfd0191bc019c4e", null ],
    [ "SLIPIF_THREAD_STACKSIZE", "group__lwip__opts__thread.html#gae8ab54a25007ce997bbab6289815e258", null ],
    [ "TCPIP_MBOX_SIZE", "group__lwip__opts__thread.html#ga8cf210ad4e4bf616860a45fbd140fd06", null ],
    [ "TCPIP_THREAD_NAME", "group__lwip__opts__thread.html#ga405e604e4328e1feb878c6fe1798a587", null ],
    [ "TCPIP_THREAD_PRIO", "group__lwip__opts__thread.html#ga42b2c7a3042d7c3efd00f367f5837435", null ],
    [ "TCPIP_THREAD_STACKSIZE", "group__lwip__opts__thread.html#gaa02b84eafa0c8b09b158b97c96d79db0", null ]
];