var mem_8c =
[
    [ "mem", "structmem.html", "structmem" ],
    [ "MIN_SIZE", "mem_8c.html#a278694c2333c9826f21ddd2c2d220f66", null ],
    [ "mem_calloc", "mem_8c.html#ab0bdc525971701883f2065e7fb257a24", null ],
    [ "mem_free", "mem_8c.html#a65169147c44e9db60d997819af9b455c", null ],
    [ "mem_init", "mem_8c.html#a44a136e3b70c36abb6f8dc060c778113", null ],
    [ "mem_malloc", "mem_8c.html#af418ade27d91d41e6143dba2cc246b0f", null ],
    [ "mem_trim", "mem_8c.html#a7e6b7f11bb50bead9b35515d9a517124", null ],
    [ "ram_heap", "mem_8c.html#a6da602f2bbf1d555556f9260b3b8ad5f", null ]
];