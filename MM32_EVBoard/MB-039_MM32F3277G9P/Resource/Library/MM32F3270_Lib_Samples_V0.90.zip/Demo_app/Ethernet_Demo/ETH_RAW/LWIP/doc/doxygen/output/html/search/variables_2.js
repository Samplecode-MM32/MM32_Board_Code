var searchData=
[
  ['b',['b',['../structapi__msg.html#ab0abd60527e96cc24c2c20c835cdac05',1,'api_msg']]],
  ['base',['base',['../structmemp__desc.html#a9aec58adcbcd88167247296ca4346558',1,'memp_desc']]],
  ['bc',['bc',['../structapi__msg.html#a1705127c6cd22c2c6dbbcc59834e41e0',1,'api_msg']]],
  ['body',['body',['../structsmtp__session.html#a7bb4bf5cc209e073341b56845e5cbd49',1,'smtp_session']]],
  ['body_5flen',['body_len',['../structsmtp__session.html#a0da8b775ddfe5f8891464037a6b4bb4d',1,'smtp_session']]],
  ['body_5fsent',['body_sent',['../structsmtp__session.html#a5893c61d863b4846a81d8a4bbcaebb5b',1,'smtp_session']]]
];
