var lwip_2netdb_8h =
[
    [ "EAI_NONAME", "lwip_2netdb_8h.html#a0bb00f48d6ba1e8c55b7d85c8e3a19a7", null ],
    [ "freeaddrinfo", "group__netdbapi.html#gab28cd3049bcf6e2bc3a71e968a64a92d", null ],
    [ "getaddrinfo", "group__netdbapi.html#ga558191530d91c101621b49e43bd5bbf5", null ],
    [ "gethostbyname", "group__netdbapi.html#ga39746b4b096060ca3e8c6ee7a7560b1d", null ],
    [ "gethostbyname_r", "group__netdbapi.html#ga76204a4d646dba393f88aa9b0980fc07", null ],
    [ "lwip_freeaddrinfo", "lwip_2netdb_8h.html#a7f65ff5982a0743849a644ef2cd15ef5", null ],
    [ "lwip_getaddrinfo", "lwip_2netdb_8h.html#af356989c172a51187e22b557f22d4165", null ],
    [ "lwip_gethostbyname", "lwip_2netdb_8h.html#a8adc6d35c068a073369edde71c678cbc", null ],
    [ "lwip_gethostbyname_r", "lwip_2netdb_8h.html#afa229e90916f6c8d6308828f45351d2d", null ],
    [ "h_errno", "lwip_2netdb_8h.html#a2a1ce3f2040007303d36c0b682b5ac10", null ]
];