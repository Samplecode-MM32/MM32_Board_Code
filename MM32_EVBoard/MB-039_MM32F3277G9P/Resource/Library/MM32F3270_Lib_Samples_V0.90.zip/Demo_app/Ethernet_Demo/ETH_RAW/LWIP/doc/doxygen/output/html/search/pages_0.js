var searchData=
[
  ['changelog',['Changelog',['../changelog.html',1,'']]],
  ['common_20pitfalls',['Common pitfalls',['../pitfalls.html',1,'']]]
];
