var searchData=
[
  ['zepif_5finit',['zepif_init',['../structzepif__init.html',1,'']]]
];
