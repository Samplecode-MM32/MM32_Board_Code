var group__lwip__opts__netif =
[
    [ "Loopback interface", "group__lwip__opts__loop.html", "group__lwip__opts__loop" ],
    [ "LWIP_NETIF_API", "group__lwip__opts__netif.html#gadd45fb65f2d0e6de5a0d14ff9e101b77", null ],
    [ "LWIP_NETIF_EXT_STATUS_CALLBACK", "group__lwip__opts__netif.html#ga090482867ba04d442ab5b8ad745c0e1e", null ],
    [ "LWIP_NETIF_HOSTNAME", "group__lwip__opts__netif.html#gaa714dbfa66822ec4c6111bdb8cf753c1", null ],
    [ "LWIP_NETIF_HWADDRHINT", "group__lwip__opts__netif.html#gad1d5e878d94b56ba687cef69be936ad9", null ],
    [ "LWIP_NETIF_LINK_CALLBACK", "group__lwip__opts__netif.html#ga1a446932dd927cc4136ba654c13bb97b", null ],
    [ "LWIP_NETIF_REMOVE_CALLBACK", "group__lwip__opts__netif.html#ga9c942c2e9655b06d4f73c630d30f60bf", null ],
    [ "LWIP_NETIF_STATUS_CALLBACK", "group__lwip__opts__netif.html#gaffb97d89516c38d3fcb9e44e5d707f36", null ],
    [ "LWIP_NETIF_TX_SINGLE_PBUF", "group__lwip__opts__netif.html#gabafb9f64a80e51b56c0abbcfc1f7e04e", null ],
    [ "LWIP_NUM_NETIF_CLIENT_DATA", "group__lwip__opts__netif.html#ga94a35212616f9a9aae5c98741612b936", null ],
    [ "LWIP_SINGLE_NETIF", "group__lwip__opts__netif.html#ga943063b053eeac76b0b1bcef2ddd93be", null ]
];