var searchData=
[
  ['6lowpan_20over_20ble_20_28rfc7668_29',['6LoWPAN over BLE (RFC7668)',['../group__rfc7668if.html',1,'']]],
  ['6lowpan_20_28rfc4944_29',['6LoWPAN (RFC4944)',['../group__sixlowpan.html',1,'']]]
];
