var searchData=
[
  ['zep_5fdst_5fip_5faddr',['zep_dst_ip_addr',['../structzepif__init.html#a851efb99a973348f1064a31b97ce779d',1,'zepif_init']]],
  ['zep_5fdst_5fudp_5fport',['zep_dst_udp_port',['../structzepif__init.html#a86c6229ed3010158e601666afe91a286',1,'zepif_init']]],
  ['zep_5fnetif',['zep_netif',['../structzepif__init.html#a3d97bf90b6bd4dd8258a3b1caf7890e3',1,'zepif_init']]],
  ['zep_5fsrc_5fip_5faddr',['zep_src_ip_addr',['../structzepif__init.html#adbe989f1f5cba623d742187def36f02c',1,'zepif_init']]],
  ['zep_5fsrc_5fudp_5fport',['zep_src_udp_port',['../structzepif__init.html#ad739032585841b126b4c0eab5899d40f',1,'zepif_init']]],
  ['zep_20_2d_20zigbee_20encapsulation_20protocol',['ZEP - ZigBee Encapsulation Protocol',['../group__zepif.html',1,'']]],
  ['zepif_2ec',['zepif.c',['../zepif_8c.html',1,'']]],
  ['zepif_2eh',['zepif.h',['../zepif_8h.html',1,'']]],
  ['zepif_5finit',['zepif_init',['../structzepif__init.html',1,'zepif_init'],['../group__zepif.html#gad61a6d9c1ab17e5b2c2c3eb9b42cc004',1,'zepif_init(struct netif *netif):&#160;zepif.c'],['../group__zepif.html#gad61a6d9c1ab17e5b2c2c3eb9b42cc004',1,'zepif_init(struct netif *netif):&#160;zepif.c']]],
  ['zepif_5floopback',['ZEPIF_LOOPBACK',['../zepif_8c.html#a8cae594e71cf385076f7bda166729dcd',1,'zepif.c']]],
  ['zero_2dcopy_20rx',['Zero-copy RX',['../zerocopyrx.html',1,'']]]
];
