var prot_2dhcp6_8h =
[
    [ "dhcp6_msg", "structdhcp6__msg.html", null ],
    [ "DHCP6_DUID_LLT", "prot_2dhcp6_8h.html#afe33f98cb94e0f18892a41502cf54e36", null ],
    [ "DHCP6_STATUS_SUCCESS", "prot_2dhcp6_8h.html#a878a7734e159826e82e958fe3a5ca175", null ]
];