var prot_2nd6_8h =
[
    [ "ns_header", "structns__header.html", null ],
    [ "na_header", "structna__header.html", null ],
    [ "rs_header", "structrs__header.html", null ],
    [ "redirect_header", "structredirect__header.html", null ],
    [ "ND6_OPTION_TYPE_MTU", "prot_2nd6_8h.html#aab6c15c9bea51fbdcc660f718bb403a8", null ],
    [ "ND6_OPTION_TYPE_PREFIX_INFO", "prot_2nd6_8h.html#a0225d4c8911efdbdbc2b40de208906c2", null ],
    [ "ND6_OPTION_TYPE_RDNSS", "prot_2nd6_8h.html#a3188b9704a8ca598f54b87c3db73272e", null ],
    [ "ND6_OPTION_TYPE_REDIR_HDR", "prot_2nd6_8h.html#aeaa575c1a66ccaa2dc62ff2c0bd71619", null ],
    [ "ND6_OPTION_TYPE_ROUTE_INFO", "prot_2nd6_8h.html#aff2e03766ee1fa15263c4aeda5097d28", null ],
    [ "ND6_OPTION_TYPE_SOURCE_LLADDR", "prot_2nd6_8h.html#a68ce8550a20cd30093d6e79e1ca51842", null ],
    [ "ND6_RA_FLAG_MANAGED_ADDR_CONFIG", "prot_2nd6_8h.html#a7fb1b330719d83b7525374f4beca51bc", null ]
];