var searchData=
[
  ['fold_5fu32t',['FOLD_U32T',['../inet__chksum_8h.html#a6ffe83b4bdd1784a0671ee4778966a01',1,'inet_chksum.h']]]
];
