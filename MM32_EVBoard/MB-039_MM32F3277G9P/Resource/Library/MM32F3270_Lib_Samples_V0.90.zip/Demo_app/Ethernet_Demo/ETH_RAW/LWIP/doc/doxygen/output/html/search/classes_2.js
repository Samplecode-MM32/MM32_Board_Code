var searchData=
[
  ['bridgeif_5finitdata_5fs',['bridgeif_initdata_s',['../structbridgeif__initdata__s.html',1,'']]]
];
