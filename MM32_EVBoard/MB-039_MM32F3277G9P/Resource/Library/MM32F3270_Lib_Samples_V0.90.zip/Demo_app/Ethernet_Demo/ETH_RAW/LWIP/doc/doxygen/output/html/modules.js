var modules =
[
    [ "lwIP", "group__lwip.html", "group__lwip" ],
    [ "Infrastructure", "group__infrastructure.html", "group__infrastructure" ],
    [ "APIs", "group__api.html", "group__api" ],
    [ "NETIFs", "group__netifs.html", "group__netifs" ],
    [ "Applications", "group__apps.html", "group__apps" ]
];