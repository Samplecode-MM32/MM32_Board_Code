var searchData=
[
  ['zepif_5finit',['zepif_init',['../group__zepif.html#gad61a6d9c1ab17e5b2c2c3eb9b42cc004',1,'zepif_init(struct netif *netif):&#160;zepif.c'],['../group__zepif.html#gad61a6d9c1ab17e5b2c2c3eb9b42cc004',1,'zepif_init(struct netif *netif):&#160;zepif.c']]]
];
