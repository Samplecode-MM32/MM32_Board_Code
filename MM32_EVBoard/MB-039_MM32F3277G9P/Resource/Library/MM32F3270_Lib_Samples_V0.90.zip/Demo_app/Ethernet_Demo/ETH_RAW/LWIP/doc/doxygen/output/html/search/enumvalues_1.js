var searchData=
[
  ['httpc_5fresult_5ferr_5fclosed',['HTTPC_RESULT_ERR_CLOSED',['../group__httpc.html#gga49e34884b272b1e0ddae8da46c31d9a3a89a6700abb14dd7cab9b4e0fd66e5fd6',1,'http_client.h']]],
  ['httpc_5fresult_5ferr_5fconnect',['HTTPC_RESULT_ERR_CONNECT',['../group__httpc.html#gga49e34884b272b1e0ddae8da46c31d9a3ab866d5433b4c4593c80b756d434e1d09',1,'http_client.h']]],
  ['httpc_5fresult_5ferr_5fcontent_5flen',['HTTPC_RESULT_ERR_CONTENT_LEN',['../group__httpc.html#gga49e34884b272b1e0ddae8da46c31d9a3a6c8a4195834e1997a498a03bb47bb096',1,'http_client.h']]],
  ['httpc_5fresult_5ferr_5fhostname',['HTTPC_RESULT_ERR_HOSTNAME',['../group__httpc.html#gga49e34884b272b1e0ddae8da46c31d9a3ae04714f90692c122e6c85e06083dbc6d',1,'http_client.h']]],
  ['httpc_5fresult_5ferr_5fmem',['HTTPC_RESULT_ERR_MEM',['../group__httpc.html#gga49e34884b272b1e0ddae8da46c31d9a3a49972833ec01c7a10dee734c7c69ed62',1,'http_client.h']]],
  ['httpc_5fresult_5ferr_5fsvr_5fresp',['HTTPC_RESULT_ERR_SVR_RESP',['../group__httpc.html#gga49e34884b272b1e0ddae8da46c31d9a3aaa023a6f8069c02c87a826ba323c54b8',1,'http_client.h']]],
  ['httpc_5fresult_5ferr_5ftimeout',['HTTPC_RESULT_ERR_TIMEOUT',['../group__httpc.html#gga49e34884b272b1e0ddae8da46c31d9a3a8e6c597f88335b31e6a8b078a32fde33',1,'http_client.h']]],
  ['httpc_5fresult_5ferr_5funknown',['HTTPC_RESULT_ERR_UNKNOWN',['../group__httpc.html#gga49e34884b272b1e0ddae8da46c31d9a3a5026187026abd1d242333ba6ff69ddbd',1,'http_client.h']]],
  ['httpc_5fresult_5flocal_5fabort',['HTTPC_RESULT_LOCAL_ABORT',['../group__httpc.html#gga49e34884b272b1e0ddae8da46c31d9a3adf4e45365923c16b6a6879bde5f60867',1,'http_client.h']]],
  ['httpc_5fresult_5fok',['HTTPC_RESULT_OK',['../group__httpc.html#gga49e34884b272b1e0ddae8da46c31d9a3af3173d4d272c9c0b5a5c9b5b027e3659',1,'http_client.h']]]
];
