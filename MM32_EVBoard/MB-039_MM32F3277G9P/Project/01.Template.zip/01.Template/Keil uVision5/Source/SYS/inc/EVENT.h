/*******************************************************************************
 * @file    EVENT.h
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __EVENT_H__
#define __EVENT_H__


#ifdef __cplusplus
 extern "C" {
#endif 


#undef EXTERN


#ifdef  __EVENT_C__
#define EXTERN
#else
#define EXTERN extern
#endif


/* Includes ------------------------------------------------------------------*/
#include "config.h"


/* Exported types ------------------------------------------------------------*/
typedef enum
{
    EVENT_TYPE_NULL = 0,
    EVENT_TYPE_LED  = 1,
    EVENT_TYPE_KEY  = 2,
    EVENT_TYPE_OTHER,
} eEVENT_TYPE;


typedef struct
{
    uint8_t type;
    uint8_t param1;
    uint8_t param2;
} EVENT_TypeDef;


/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/


/* Exported functions ------------------------------------------------------- */
EXTERN void EVENT_Send(uint8_t type, uint8_t param1, uint8_t param2);
EXTERN void EVENT_Scanning(void);


#ifdef __cplusplus
}
#endif


#endif


/******************* (C) COPYRIGHT 2021 ************************END OF FILE****/

