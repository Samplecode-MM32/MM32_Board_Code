/*******************************************************************************
 * @file    QUEUE.c
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#define __QUEUE_C__


/* Includes ------------------------------------------------------------------*/
#include "QUEUE.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/


/* Private variables ---------------------------------------------------------*/
static QUEUE_InitTypeDef QUEUE[QUEUE_NUMBER];


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void QUEUE_INIT(uint8_t index)
{
    QUEUE[index].head = 0;
    QUEUE[index].tail = 0;

    memset(QUEUE[index].dat, 0, sizeof(QUEUE[index].dat));
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint8_t QUEUE_EMPTY(uint8_t index)
{
    if(QUEUE[index].head == QUEUE[index].tail)  return 1;
    else                                        return 0;
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint8_t QUEUE_READ(uint8_t index)
{
    uint8_t dat = QUEUE[index].dat[QUEUE[index].head++];
    QUEUE[index].head %= QUEUE_SIZE;         return dat;
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void QUEUE_WRITE(uint8_t index, uint8_t dat)
{
    QUEUE[index].dat[QUEUE[index].tail++] = dat;
    QUEUE[index].tail %= QUEUE_SIZE;
}


/******************* (C) COPYRIGHT 2021 ************************END OF FILE****/

