/*******************************************************************************
 * @file    EVENT.c
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#define __EVENT_C__


/* Includes ------------------------------------------------------------------*/
#include "EVENT.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/


/* Private variables ---------------------------------------------------------*/
static EVENT_TypeDef PendingEvent;


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void EVENT_Send(uint8_t type, uint8_t param1, uint8_t param2)
{
    PendingEvent.type   = type;
    PendingEvent.param1 = param1;
    PendingEvent.param2 = param2;
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void EVENT_Handler(EVENT_TypeDef event)
{
    switch(event.type)
    {
        case EVENT_TYPE_NULL:
            break;

        case EVENT_TYPE_KEY:
            KEY_Handler((eKEY_VALUE)(event.param1), (eKEY_TYPE)(event.param2));
            break;

        default: break;
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void EVENT_Scanning(void)
{
    if(PendingEvent.type != EVENT_TYPE_NULL)
    {
        EVENT_Handler(PendingEvent);

        PendingEvent.type = EVENT_TYPE_NULL;
    }
}


/******************* (C) COPYRIGHT 2021 ************************END OF FILE****/

