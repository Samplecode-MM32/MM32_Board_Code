/*******************************************************************************
 * @file    DWT.h
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DWT_H__
#define __DWT_H__


#ifdef __cplusplus
 extern "C" {
#endif 


#undef EXTERN


#ifdef  __DWT_C__
#define EXTERN
#else
#define EXTERN extern
#endif


/* Includes ------------------------------------------------------------------*/
#include "config.h"


/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/


/* Exported functions ------------------------------------------------------- */
EXTERN void DWT_Init(void);
EXTERN void DWT_DelayUS(uint32_t Count);


#ifdef __cplusplus
}
#endif


#endif


/******************* (C) COPYRIGHT 2021 ************************END OF FILE****/

