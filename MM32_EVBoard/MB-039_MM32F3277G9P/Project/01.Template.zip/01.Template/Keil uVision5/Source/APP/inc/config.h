/*******************************************************************************
 * @file    config.h
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CONFIG_H__
#define __CONFIG_H__


/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


/* Includes ------------------------------------------------------------------*/
#include "mm32_device.h"
#include "hal_conf.h"


/* Includes ------------------------------------------------------------------*/
#include "ADC.h"
#include "BUZZER.h"
#include "CAN.h"
#include "EEPROM.h"
#include "KEY.h"
#include "LCD.h"
#include "LED.h"
#include "MCU.h"
#include "RTC.h"
#include "SPI_FLASH.h"


/* Includes ------------------------------------------------------------------*/
#include "DWT.h"
#include "EVENT.h"
#include "MESSAGE.h"
#include "QUEUE.h"
#include "TASK.h"


/* Includes ------------------------------------------------------------------*/
#include "shell.h"
#include "shell_cfg.h"
#include "shell_ext.h"
#include "shell_port.h"


/* Includes ------------------------------------------------------------------*/
#include "xprintf.h"
#include "xprintf_port.h"


#endif


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

