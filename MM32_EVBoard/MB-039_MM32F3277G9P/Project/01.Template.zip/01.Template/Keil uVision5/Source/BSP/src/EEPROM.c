/*******************************************************************************
 * @file    EEPROM.c
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#define __EEPROM_C__


/* Includes ------------------------------------------------------------------*/
#include "EEPROM.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/* Exported variables --------------------------------------------------------*/
/* Exported function prototypes ----------------------------------------------*/


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void I2C_DeInitGPIO(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOB, ENABLE);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void I2C_InitGPIO(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOB, ENABLE);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_OD;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_4);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_4);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void I2C_Configure(void)
{
    I2C_InitTypeDef I2C_InitStructure;

    I2C_DeInitGPIO();

    RCC_APB1PeriphClockCmd(RCC_APB1ENR_I2C1,   ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2ENR_SYSCFG, ENABLE);

    I2C_StructInit(&I2C_InitStructure);
    I2C_InitStructure.I2C_Mode       = I2C_Mode_MASTER;
    I2C_InitStructure.I2C_OwnAddress = 0;
    I2C_InitStructure.I2C_Speed      = I2C_Speed_STANDARD;
    I2C_InitStructure.I2C_ClockSpeed = 100000;
    I2C_Init(I2C1, &I2C_InitStructure);

    I2C_Send7bitAddress(I2C1, EEPROM_I2C_ADDRESS, I2C_Direction_Transmitter);

    I2C_Cmd(I2C1, ENABLE);

    I2C_InitGPIO();
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void I2C_ReadBuffer(uint8_t Address, uint8_t *Buffer, uint8_t Length)
{
    uint8_t Flag = 0, Count = 0;

    I2C_SendData(I2C1, Address);
    while(!I2C_GetFlagStatus(I2C1, I2C_STATUS_FLAG_TFE));

    for(uint8_t i = 0; i < Length; i++)
    {
        while(1)
        {
            if((I2C_GetFlagStatus(I2C1, I2C_STATUS_FLAG_TFNF)) && (Flag == 0))
            {
                I2C_ReadCmd(I2C1);   Count++;

                if(Count == Length) Flag = 1;
            }

            if(I2C_GetFlagStatus(I2C1, I2C_STATUS_FLAG_RFNE))
            {
                Buffer[i] = I2C_ReceiveData(I2C1);     break;
            }
        }
    }

    I2C_GenerateSTOP(I2C1, ENABLE);
    while(!I2C_GetFlagStatus(I2C1, I2C_FLAG_STOP_DET));
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void I2C_WriteBuffer(uint8_t Address, uint8_t *Buffer, uint8_t Length)
{
    I2C_SendData(I2C1, Address);
    while(!I2C_GetFlagStatus(I2C1, I2C_STATUS_FLAG_TFE));

    for(uint8_t i = 0; i < Length; i++)
    {
        I2C_SendData(I2C1, *Buffer++);
        while(!I2C_GetFlagStatus(I2C1, I2C_STATUS_FLAG_TFE));
    }

    I2C_GenerateSTOP(I2C1, ENABLE);
    while(!I2C_GetFlagStatus(I2C1, I2C_FLAG_STOP_DET));
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void EEPROM_ReadData(uint8_t Address, uint8_t *Buffer, uint8_t Length)
{
    I2C_ReadBuffer(Address, Buffer, Length);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void EEPROM_WriteData(uint8_t Address, uint8_t *Buffer, uint8_t Length)
{
    uint8_t Start, StartCount, PageNumber, FinalCount;

    /*
     * EEPROM��Ҫ��ҳд��, ���ݵ�ǰ��д����ʼ��ַ�����ݳ��Ƚ����жϴ���
     */
    if((Address % EEPROM_PAGE_SIZE) == 0)
    {
        StartCount = 0;
        PageNumber = Length / EEPROM_PAGE_SIZE;
        FinalCount = Length % EEPROM_PAGE_SIZE;
    }
    else
    {
        Start = Address % EEPROM_PAGE_SIZE;

        if(((Start + Length) / EEPROM_PAGE_SIZE) == 0)
        {
            StartCount = Length;
            PageNumber = 0;
            FinalCount = 0;
        }
        else
        {
            StartCount = EEPROM_PAGE_SIZE - Start;
            PageNumber = (Length - StartCount) / EEPROM_PAGE_SIZE;
            FinalCount = (Length - StartCount) % EEPROM_PAGE_SIZE;
        }
    }

    if(StartCount)
    {
        I2C_WriteBuffer(Address, Buffer, StartCount);
        Address += StartCount;
        Buffer  += StartCount;

        printf("\r\nWait A Moument...");
    }

    while(PageNumber--)
    {
        I2C_WriteBuffer(Address, Buffer, EEPROM_PAGE_SIZE);

        Address += EEPROM_PAGE_SIZE;
        Buffer  += EEPROM_PAGE_SIZE;

        printf("\r\nWait A Moument...");
    }

    if(FinalCount)
    {
        I2C_WriteBuffer(Address, Buffer, FinalCount);
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void EEPROM_Init(void)
{
    I2C_Configure();
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void EEPROM_SHELL_Handler(void)
{
    uint8_t rBuffer[20], wBuffer[20];
    uint8_t Address = 0;

    uint8_t Length = 20;

    for(uint8_t i = 0; i < 20; i++)
    {
        rBuffer[i] = 0;
        wBuffer[i] = i;
    }

    printf("\r\n\r\nEEPROM Write Data : ");

    EEPROM_WriteData(Address, wBuffer, Length);

    printf("OK");


    printf("\r\n\r\nEEPROM Read  Data : \r\n");

    EEPROM_ReadData(Address, rBuffer, Length);

    for(uint8_t i = 0; i < Length; i++)
    {
        printf("0x%02x ", rBuffer[i]);

        if(((i + 1) % 10) == 0) printf("\r\n");
    }

    printf("\r\n\r\n");
}
SHELL_EXPORT_CMD(EEPROM, EEPROM_SHELL_Handler, EEPROM Write And Read Out);


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

