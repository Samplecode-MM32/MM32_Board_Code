/*******************************************************************************
 * @file    SPI_FLASH.c
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#define __SPI_FLASH_C__


/* Includes ------------------------------------------------------------------*/
#include "SPI_FLASH.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/


/* Private variables ---------------------------------------------------------*/
uint8_t SPI_FLASH_Buffer[SPI_FLASH_SECTOR_SIZE];


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/* Exported variables --------------------------------------------------------*/
/* Exported function prototypes ----------------------------------------------*/


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_Configure(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    SPI_InitTypeDef  SPI_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1ENR_SPI2, ENABLE);

    SPI_StructInit(&SPI_InitStructure);
    SPI_InitStructure.SPI_Mode              = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize          = SPI_DataSize_8b;
    SPI_InitStructure.SPI_DataWidth         = 8;
    SPI_InitStructure.SPI_CPOL              = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA              = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS               = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_256;
    SPI_InitStructure.SPI_FirstBit          = SPI_FirstBit_MSB;
    SPI_Init(SPI2, &SPI_InitStructure);

    SPI_Cmd(SPI2, ENABLE);

    RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOB,    ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2ENR_SYSCFG, ENABLE);

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource12, GPIO_AF_5);   /* PB12 SPI2_NSS  */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource13, GPIO_AF_5);   /* PB13 SPI2_SCK  */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource14, GPIO_AF_5);   /* PB14 SPI2_MISO */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource15, GPIO_AF_5);   /* PB14 SPI2_MOSI */

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    SPI_BiDirectionalLineConfig(SPI2, SPI_Direction_Rx);
    SPI_BiDirectionalLineConfig(SPI2, SPI_Direction_Tx);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint8_t SPI_ReadWriteByte(uint8_t Data)
{
    SPI_SendData(SPI2, Data);
    while(!SPI_GetFlagStatus(SPI2, SPI_FLAG_TXEPT));

    while(!SPI_GetFlagStatus(SPI2, SPI_FLAG_RXAVL));
    return SPI_ReceiveData(SPI2);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint8_t SPI_FLASH_ReadSR1(void)
{
    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0x05);
    uint8_t value = SPI_ReadWriteByte(0xFF);

    SPI_CSInternalSelected(SPI2, DISABLE);

    return value;
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_WriteSR1(uint8_t Data)
{
    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0x01);
    SPI_ReadWriteByte(Data);

    SPI_CSInternalSelected(SPI2, DISABLE);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_WriteDisable(void)
{
    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0x04);

    SPI_CSInternalSelected(SPI2, DISABLE);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_WriteEnable(void)
{
    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0x06);

    SPI_CSInternalSelected(SPI2, DISABLE);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_ReadDeviceID(void)
{
    uint16_t DeviceID = 0;

    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0x90);

    SPI_ReadWriteByte(0xFF);
    SPI_ReadWriteByte(0xFF);
    SPI_ReadWriteByte(0x00);

    DeviceID   = SPI_ReadWriteByte(0xFF);
    DeviceID <<= 8;
    DeviceID  |= SPI_ReadWriteByte(0xFF);

    SPI_CSInternalSelected(SPI2, DISABLE);

    printf("\r\n\r\nSPI Flash DeviceID : 0x%04x", DeviceID);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_ReadJEDEC_ID(void)
{
    uint32_t JEDEC_ID = 0;

    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0x9F);

    JEDEC_ID   = SPI_ReadWriteByte(0xFF);
    JEDEC_ID <<= 8;
    JEDEC_ID  |= SPI_ReadWriteByte(0xFF);
    JEDEC_ID <<= 8;
    JEDEC_ID  |= SPI_ReadWriteByte(0xFF);

    SPI_CSInternalSelected(SPI2, DISABLE);

    printf("\r\n\r\nSPI Flash JEDEC ID : 0x%06x", JEDEC_ID);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_WaitBusy(void)
{
    while((SPI_FLASH_ReadSR1() & 0x01) == 0x01);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_PowerDown(void)
{
    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0xB9);

    SPI_CSInternalSelected(SPI2, DISABLE);

    for(uint8_t i = 0; i < 200; i++);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_WakeUp(void)
{
    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0xAB);

    SPI_CSInternalSelected(SPI2, DISABLE);

    for(uint8_t i = 0; i < 200; i++);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_EraseChip(void)
{
    SPI_FLASH_WriteEnable();
    SPI_FLASH_WaitBusy();

    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0xC7);

    SPI_CSInternalSelected(SPI2, DISABLE);

    SPI_FLASH_WaitBusy();
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_SectorErase(uint16_t Sector)
{
    uint32_t Address = Sector * 4 * 1024;

    SPI_FLASH_WriteEnable();
    SPI_FLASH_WaitBusy();

    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0x20);

    SPI_ReadWriteByte((uint8_t)((Address >> 16) & 0x000000FF));
    SPI_ReadWriteByte((uint8_t)((Address >>  8) & 0x000000FF));
    SPI_ReadWriteByte((uint8_t)((Address >>  0) & 0x000000FF));

    SPI_CSInternalSelected(SPI2, DISABLE);

    SPI_FLASH_WaitBusy();
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_BlockErase32K(uint16_t Block)
{
    uint32_t Address = Block * 32 * 1024;

    SPI_FLASH_WriteEnable();
    SPI_FLASH_WaitBusy();

    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0x52);

    SPI_ReadWriteByte((uint8_t)((Address >> 16) & 0x000000FF));
    SPI_ReadWriteByte((uint8_t)((Address >>  8) & 0x000000FF));
    SPI_ReadWriteByte((uint8_t)((Address >>  0) & 0x000000FF));

    SPI_CSInternalSelected(SPI2, DISABLE);

    SPI_FLASH_WaitBusy();
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_BlockErase64K(uint16_t Block)
{
    uint32_t Address = Block * 64 * 1024;

    SPI_FLASH_WriteEnable();
    SPI_FLASH_WaitBusy();

    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0xD8);

    SPI_ReadWriteByte((uint8_t)((Address >> 16) & 0x000000FF));
    SPI_ReadWriteByte((uint8_t)((Address >>  8) & 0x000000FF));
    SPI_ReadWriteByte((uint8_t)((Address >>  0) & 0x000000FF));

    SPI_CSInternalSelected(SPI2, DISABLE);

    SPI_FLASH_WaitBusy();
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_ReadData(uint32_t Address, uint8_t *Buffer, uint32_t Number)
{
    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0x03);

    SPI_ReadWriteByte((uint8_t)((Address >> 16) & 0x000000FF));
    SPI_ReadWriteByte((uint8_t)((Address >>  8) & 0x000000FF));
    SPI_ReadWriteByte((uint8_t)((Address >>  0) & 0x000000FF));

    for(uint32_t i = 0; i < Number; i++)
    {
        Buffer[i] = SPI_ReadWriteByte(0xFF);
    }

    SPI_CSInternalSelected(SPI2, DISABLE);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_FastRead(uint32_t Address, uint8_t *Buffer, uint32_t Number)
{
    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0x0B);

    SPI_ReadWriteByte((uint8_t)((Address >> 16) & 0x000000FF));
    SPI_ReadWriteByte((uint8_t)((Address >>  8) & 0x000000FF));
    SPI_ReadWriteByte((uint8_t)((Address >>  0) & 0x000000FF));

    SPI_ReadWriteByte(0xFF);

    for(uint32_t i = 0; i < Number; i++)
    {
        Buffer[i] = SPI_ReadWriteByte(0xFF);
    }

    SPI_CSInternalSelected(SPI2, DISABLE);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_PageProgram(uint32_t Address, uint8_t *Buffer, uint32_t Number)
{
    SPI_FLASH_WriteEnable();

    SPI_CSInternalSelected(SPI2, ENABLE);

    SPI_ReadWriteByte(0x02);

    SPI_ReadWriteByte((uint8_t)((Address >> 16) & 0x000000FF));
    SPI_ReadWriteByte((uint8_t)((Address >>  8) & 0x000000FF));
    SPI_ReadWriteByte((uint8_t)((Address >>  0) & 0x000000FF));

    for(uint32_t i = 0; i < Number; i++)
    {
        SPI_ReadWriteByte(Buffer[i]);
    }

    SPI_CSInternalSelected(SPI2, DISABLE);

    SPI_FLASH_WaitBusy();
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_WriteWithoutCheck(uint32_t Address, uint8_t *Buffer, uint32_t Number)
{
    uint16_t PageRemain = 256 - (Address % 256);

    if(Number <= PageRemain)
    {
        PageRemain = Number;
    }

    while(1)
    {
        SPI_FLASH_PageProgram(Address, Buffer, PageRemain);

        if(PageRemain == Number)
        {
            break;
        }
        else
        {
            Buffer  += PageRemain;
            Address += PageRemain;
            Number  -= PageRemain;

            if(Number > SPI_FLASH_PAGE_SIZE)
            {
                PageRemain = SPI_FLASH_PAGE_SIZE;
            }
            else
            {
                PageRemain = Number;
            }
        }
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_WriteWithCheck(uint32_t Address, uint8_t *Buffer, uint32_t Number)
{
    uint32_t SectorIndex;
    uint16_t SectorOffset;
    uint16_t SectorRemain;

    uint16_t i;

    SectorIndex  = Address / SPI_FLASH_SECTOR_SIZE;
    SectorOffset = Address % SPI_FLASH_SECTOR_SIZE;
    SectorRemain = SPI_FLASH_SECTOR_SIZE - SectorOffset;

    if(Number <= SectorRemain) SectorRemain = Number;

    while(1)
    {
        memset(SPI_FLASH_Buffer, 0, sizeof(SPI_FLASH_Buffer));

        SPI_FLASH_FastRead(SectorIndex * SPI_FLASH_SECTOR_SIZE, SPI_FLASH_Buffer, SPI_FLASH_SECTOR_SIZE);

        for(i = 0; i < SPI_FLASH_SECTOR_SIZE; i++)
        {
            if(SPI_FLASH_Buffer[i] != 0xFF) break;
        }

        if(i < SPI_FLASH_SECTOR_SIZE)
        {
            SPI_FLASH_SectorErase(SectorIndex);

            for(i = 0; i < SectorRemain; i++)
            {
                SPI_FLASH_Buffer[i + SectorOffset] = Buffer[i];
            }

            SPI_FLASH_WriteWithoutCheck(Address, SPI_FLASH_Buffer, SectorRemain);
        }
        else
        {
            SPI_FLASH_WriteWithoutCheck(Address, Buffer, SectorRemain);
        }

        if(Number == SectorRemain)
        {
            break;
        }
        else
        {
            SectorIndex += 1;
            SectorOffset = 0;

            Buffer  += SectorRemain;
            Address += SectorRemain;
            Number  -= SectorRemain;

            if(Number > 4096) SectorRemain = 4096;
            else              SectorRemain = Number;
        }
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_Init(void)
{
    SPI_Configure();
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SPI_FLASH_SHELL_Handler(void)
{
    uint8_t Delta = 100;
    uint8_t Buffer[100];

    SPI_FLASH_ReadDeviceID();

    SPI_FLASH_ReadJEDEC_ID();

    printf("\r\n\r\nSPI_FLASH Write Data : ");

    memset(Buffer, 0, sizeof(Buffer));

    for(uint8_t i = 0; i < sizeof(Buffer); i++)
    {
        Buffer[i] = i + Delta;
    }

    SPI_FLASH_WriteWithCheck(0, Buffer, sizeof(Buffer));

    printf("OK");

    printf("\r\n\r\nSPI_FLASH Read  Data : \r\n");

    memset(Buffer, 0, sizeof(Buffer));

    SPI_FLASH_ReadData(0, Buffer, sizeof(Buffer));

    for(uint8_t i = 0; i < sizeof(Buffer); i++)
    {
        printf("0x%02x ", Buffer[i]);

        if(((i + 1) % 10) == 0) printf("\r\n");
    }

    printf("\r\n\r\n");
}
SHELL_EXPORT_CMD(SPI_FLASH, SPI_FLASH_SHELL_Handler, SPI Flash Write And Read Out);


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

