/*******************************************************************************
 * @file    SPI_FLASH.h
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SPI_FLASH_H__
#define __SPI_FLASH_H__


#ifdef __cplusplus
extern "C" {
#endif


#undef  EXTERN

#ifdef  __SPI_FLASH_C__
#define EXTERN
#else
#define EXTERN extern
#endif


/* Includes ------------------------------------------------------------------*/
#include "config.h"


/* Exported constants --------------------------------------------------------*/
#define SPI_FLASH_PAGE_SIZE     256
#define SPI_FLASH_SECTOR_SIZE   4096


/* Exported types ------------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/


/* Exported functions --------------------------------------------------------*/
EXTERN void SPI_FLASH_Init(void);


#ifdef __cplusplus
}
#endif


#endif


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

