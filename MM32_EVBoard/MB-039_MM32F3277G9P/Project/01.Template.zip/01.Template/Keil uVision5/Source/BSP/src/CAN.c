/*******************************************************************************
 * @file    CAN.c
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#define __CAN_C__


/* Includes ------------------------------------------------------------------*/
#include "CAN.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/


/* Private variables ---------------------------------------------------------*/
CanPeliRxMsg CanPeliRxMessage;
volatile u8 CANPeliRxFlag = 0;


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/* Exported variables --------------------------------------------------------*/
/* Exported function prototypes ----------------------------------------------*/


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void CAN_InitGPIO(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_AHBPeriphClockCmd( RCC_AHBENR_GPIOB,   ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2ENR_SYSCFG, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1ENR_CAN,    ENABLE);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_8;         //---PB8 CAN_RX
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_FLOATING;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_9;         //---PB9 CAN_TX
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;  
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_9);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_9);

    NVIC_InitStructure.NVIC_IRQChannel = CAN_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void CAN_InitFilter(uint32_t baud, CAN_Mode mode, uint32_t IDCode1, uint32_t IDCode2, uint32_t IDMask1, uint32_t IDMask2)
{
    CAN_Peli_InitTypeDef        CAN_Peli_InitStructure;
    CAN_Peli_FilterInitTypeDef  CAN_Peli_FilterInitStructure;
    RCC_ClocksTypeDef           RCC_Clocks;

    uint32_t IDCodeTemp1 = 0, IDMaskTemp1 = 0;
    uint32_t IDCodeTemp2 = 0, IDMaskTemp2 = 0;

    CAN_ResetMode_Cmd(CAN1, ENABLE);        //---���븴λģʽ
    CAN_Mode_Cmd(CAN1, CAN_PELIMode);       //---����Peliģʽ

    RCC_GetClocksFreq(&RCC_Clocks);

    CAN_Peli_StructInit(&CAN_Peli_InitStructure);
    CAN_AutoCfg_BaudParam(&CAN_Peli_InitStructure, RCC_Clocks.PCLK1_Frequency, baud);

    CAN_Peli_InitStructure.SAM  = RESET;    //---������
    CAN_Peli_InitStructure.LOM  = DISABLE;  //---ֻ��ģʽ
    CAN_Peli_InitStructure.STM  = DISABLE;  //---�Լ��ģʽ
    CAN_Peli_Init(&CAN_Peli_InitStructure);

    switch(mode)
    {
        case StandardFrame_SingleFilter:    //---��׼֡ ���˲���ģʽ

            IDCodeTemp1 = IDCode1 << (3 + 18);
            IDMaskTemp1 = IDMask1 << (3 + 18);

            CAN_Peli_FilterInitStructure.AFM                = CAN_FilterMode_Singal;

            CAN_Peli_FilterInitStructure.CAN_FilterId0      = ((IDCodeTemp1 >> 0x18) & 0xFF);
            CAN_Peli_FilterInitStructure.CAN_FilterId1      = ((IDCodeTemp1 >> 0x10) & 0xFF);
            CAN_Peli_FilterInitStructure.CAN_FilterId2      = ((IDCodeTemp1 >> 0x08) & 0xFF);
            CAN_Peli_FilterInitStructure.CAN_FilterId3      = ((IDCodeTemp1 >> 0x00) & 0xFF);

            CAN_Peli_FilterInitStructure.CAN_FilterMaskId0  = ((IDMaskTemp1 >> 0x18) & 0xFF) | 0x00;
            CAN_Peli_FilterInitStructure.CAN_FilterMaskId1  = ((IDMaskTemp1 >> 0x10) & 0xFF) | 0x1F;
            CAN_Peli_FilterInitStructure.CAN_FilterMaskId2  = ((IDMaskTemp1 >> 0x08) & 0xFF) | 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterMaskId3  = ((IDMaskTemp1 >> 0x00) & 0xFF) | 0xFF;
            break;

        case ExtendedFrame_SingleFilter:    //---��չ֡ ���˲���ģʽ

            IDCodeTemp1 = IDCode1 << 3;
            IDMaskTemp1 = IDMask1 << 3;

            CAN_Peli_FilterInitStructure.AFM                = CAN_FilterMode_Singal;

            CAN_Peli_FilterInitStructure.CAN_FilterId0      = (IDCodeTemp1 >> 0x18) & 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterId1      = (IDCodeTemp1 >> 0x10) & 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterId2      = (IDCodeTemp1 >> 0x08) & 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterId3      = (IDCodeTemp1 >> 0x00) & 0xFF;

            CAN_Peli_FilterInitStructure.CAN_FilterMaskId0  = (IDMaskTemp1 >> 0x18) & 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterMaskId1  = (IDMaskTemp1 >> 0x10) & 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterMaskId2  = (IDMaskTemp1 >> 0x08) & 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterMaskId3  = (IDMaskTemp1 >> 0x00) & 0xFF;
            break;

        case StandardFrame_DoubleFilter:    //---��׼֡ ˫�˲���ģʽ

            IDCodeTemp1 = IDCode1 << (3 + 18);
            IDCodeTemp2 = IDCode2 << (3 + 18);

            IDMaskTemp1 = IDMask1 << (3 + 18);
            IDMaskTemp2 = IDMask2 << (3 + 18);

            CAN_Peli_FilterInitStructure.AFM                = CAN_FilterMode_Double;

            CAN_Peli_FilterInitStructure.CAN_FilterId0      = ((IDCodeTemp1 >> 0x18) & 0xFF);
            CAN_Peli_FilterInitStructure.CAN_FilterId1      = ((IDCodeTemp1 >> 0x10) & 0xFF);
            CAN_Peli_FilterInitStructure.CAN_FilterId2      = ((IDCodeTemp2 >> 0x18) & 0xFF);
            CAN_Peli_FilterInitStructure.CAN_FilterId3      = ((IDCodeTemp2 >> 0x10) & 0xFF);

            CAN_Peli_FilterInitStructure.CAN_FilterMaskId0  = ((IDMaskTemp1 >> 0x18) & 0xFF) | 0x00;
            CAN_Peli_FilterInitStructure.CAN_FilterMaskId1  = ((IDMaskTemp1 >> 0x10) & 0xFF) | 0x1F;
            CAN_Peli_FilterInitStructure.CAN_FilterMaskId2  = ((IDMaskTemp2 >> 0x18) & 0xFF) | 0x00;
            CAN_Peli_FilterInitStructure.CAN_FilterMaskId3  = ((IDMaskTemp2 >> 0x10) & 0xFF) | 0x1F;
            break;

        case ExtendedFrame_DoubleFilter:    //---��չ֡ ˫�˲���ģʽ

            IDCodeTemp1 = IDCode1 << 3;
            IDCodeTemp2 = IDCode2 << 3;

            IDMaskTemp1 = IDMask1 << 3;
            IDMaskTemp2 = IDMask2 << 3;

            CAN_Peli_FilterInitStructure.AFM                = CAN_FilterMode_Double;

            CAN_Peli_FilterInitStructure.CAN_FilterId0      = (IDCodeTemp1 >> 0x18) & 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterId1      = (IDCodeTemp1 >> 0x10) & 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterId2      = (IDCodeTemp2 >> 0x18) & 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterId3      = (IDCodeTemp2 >> 0x10) & 0xFF;

            CAN_Peli_FilterInitStructure.CAN_FilterMaskId0  = (IDMaskTemp1 >> 0x18) & 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterMaskId1  = (IDMaskTemp1 >> 0x10) & 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterMaskId2  = (IDMaskTemp2 >> 0x18) & 0xFF;
            CAN_Peli_FilterInitStructure.CAN_FilterMaskId3  = (IDMaskTemp2 >> 0x10) & 0xFF;
            break;

        default: break;
    }

    CAN_Peli_FilterInit(&CAN_Peli_FilterInitStructure);

    CAN_Peli_ITConfig(CAN_IT_ALL, ENABLE);

    CAN_ResetMode_Cmd(CAN1, DISABLE);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void CAN_Configure(void)
{
    CAN_InitGPIO();

#if 1
    //---CAN�������μĴ�������λ����Ϊ���,��ֻ�ɽ������մ���Ĵ����е�����CAN ID
    CAN_InitFilter(CAN_BAUD_500K, StandardFrame_DoubleFilter, 0x100, 0x200, 0x00000000, 0x00000000);
#else
    //---CAN�������μĴ�������λ����Ϊ�����,���ɽ���IDΪ0x1xx ���� 0x2xx�豸������
    CAN_InitFilter(CAN_BAUD_500K, StandardFrame_DoubleFilter, 0x100, 0x200, 0x000000FF, 0x000000FF);

    //---CAN�������μĴ�������λ����Ϊ�����,���ɽ�������CAN ID
    CAN_InitFilter(CAN_BAUD_500K, StandardFrame_DoubleFilter, 0x100, 0x200, 0xFFFFFFFF, 0xFFFFFFFF);
#endif

    TASK_Append(TASK_ID_CAN, CAN_RxHandler, 100);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void CAN_SendFrame(CanPeliRxMsg *TxMessage)
{
    CanPeliTxMsg CanPeliTxMessage;

    if(TxMessage->FF == FRAME_FORMAT_STANDARD)
    {
        uint32_t ID = TxMessage->ID << 21;

        CanPeliTxMessage.FF   = 0x00;
        CanPeliTxMessage.IDHH = (ID >> 0x18) & 0xFF;
        CanPeliTxMessage.IDHL = (ID >> 0x10) & 0xFF;
    }
    else
    {
        uint32_t ID = TxMessage->ID << 3;

        CanPeliTxMessage.FF   = 0x01;
        CanPeliTxMessage.IDHH = (ID >> 0x18) & 0xFF;
        CanPeliTxMessage.IDHL = (ID >> 0x10) & 0xFF;
        CanPeliTxMessage.IDLH = (ID >> 0x08) & 0xFF;
        CanPeliTxMessage.IDLL = (ID >> 0x00) & 0xFF;
    }

    CanPeliTxMessage.RTR = TxMessage->RTR;
    CanPeliTxMessage.DLC = TxMessage->DLC;

    for(uint8_t i = 0; i < 8; i++)
    {
        CanPeliTxMessage.Data[i] = TxMessage->Data[i];
    }

    CAN_Peli_Transmit(&CanPeliTxMessage);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void CAN_RxHandler(void)
{
    if(CANPeliRxFlag)
    {
        CANPeliRxFlag = 0;

        printf("\r\nCAN ID : 0x%02x Data : ", CanPeliRxMessage.ID);

        for(uint8_t i = 0; i < CanPeliRxMessage.DLC; i++)
        {
            printf("0x%02x ", CanPeliRxMessage.Data[i]);
        }

        printf("\r\n");

        CAN_SendFrame(&CanPeliRxMessage);
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void CAN1_RX_IRQHandler(void)
{
    if(CAN_GetITStatus(CAN1, CAN_IT_RI) != RESET)
    {
        CAN_Peli_Receive(&CanPeliRxMessage);

        CANPeliRxFlag = 1;
    }
}


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

