/*******************************************************************************
 * @file    LED.c
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#define __LED_C__


/* Includes ------------------------------------------------------------------*/
#include "LED.h"


/* Private typedef -----------------------------------------------------------*/


/* Private define ------------------------------------------------------------*/
#define LED_NUMBER  4


/* Private macro -------------------------------------------------------------*/


/* Private variables ---------------------------------------------------------*/
LED_TypeDef LEDs[LED_NUMBER] =
{
    {RCC_AHBENR_GPIOA, GPIOA, GPIO_Pin_15, GPIO_PinSource15},
    {RCC_AHBENR_GPIOB, GPIOB, GPIO_Pin_3,  GPIO_PinSource3},
    {RCC_AHBENR_GPIOB, GPIOB, GPIO_Pin_4,  GPIO_PinSource4},
    {RCC_AHBENR_GPIOB, GPIOB, GPIO_Pin_5,  GPIO_PinSource5},
};


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/* Exported variables --------------------------------------------------------*/
/* Exported function prototypes ----------------------------------------------*/


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    for(uint8_t i = 0; i < LED_NUMBER; i++)
    {
        RCC_AHBPeriphClockCmd(LEDs[i].RCCn, ENABLE);

        GPIO_PinAFConfig(LEDs[i].GPIOn, LEDs[i].PinSource, GPIO_AF_3);

        GPIO_StructInit(&GPIO_InitStructure);
        GPIO_InitStructure.GPIO_Pin   = LEDs[i].PINn;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
        GPIO_Init(LEDs[i].GPIOn, &GPIO_InitStructure);

        GPIO_WriteBit(LEDs[i].GPIOn, LEDs[i].PINn, Bit_RESET);
    }

#if 0
    DWT_Init();

    for(uint32_t i = 0; i < 10000; i++)
    {
        GPIO_WriteBit(LEDs[0].GPIOn, LEDs[0].PINn, Bit_SET);
        DWT_DelayUS(500);
        GPIO_WriteBit(LEDs[0].GPIOn, LEDs[0].PINn, Bit_RESET);
        DWT_DelayUS(500);
    }
#endif

    TASK_Append(TASK_ID_LED, LED_Toggle, 250);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LED_Toggle(void)
{
    for(uint8_t i = 0; i < LED_NUMBER; i++)
    {
        if(!GPIO_ReadOutputDataBit(LEDs[i].GPIOn, LEDs[i].PINn))
        {
            GPIO_WriteBit(LEDs[i].GPIOn, LEDs[i].PINn, Bit_SET);
        }
        else
        {
            GPIO_WriteBit(LEDs[i].GPIOn, LEDs[i].PINn, Bit_RESET);
        }
    }
}


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

