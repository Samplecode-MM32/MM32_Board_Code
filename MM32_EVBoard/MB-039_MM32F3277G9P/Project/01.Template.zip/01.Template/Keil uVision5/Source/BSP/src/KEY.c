/*******************************************************************************
 * @file    KEY.c
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#define __KEY_C__


/* Includes ------------------------------------------------------------------*/
#include "KEY.h"


/* Private typedef -----------------------------------------------------------*/


/* Private define ------------------------------------------------------------*/
#define KEY_NUMBER  4


/* Private macro -------------------------------------------------------------*/


/* Private variables ---------------------------------------------------------*/
KEY_GROUP_TypeDef KEY_GRP[KEY_NUMBER] = 
{
    {RCC_AHBENR_GPIOB, GPIOB, GPIO_Pin_1,  GPIO_Mode_IPD, Bit_SET,   KEY_VALUE_1},
    {RCC_AHBENR_GPIOB, GPIOB, GPIO_Pin_2,  GPIO_Mode_IPU, Bit_RESET, KEY_VALUE_2},
    {RCC_AHBENR_GPIOB, GPIOB, GPIO_Pin_10, GPIO_Mode_IPU, Bit_RESET, KEY_VALUE_3},
    {RCC_AHBENR_GPIOB, GPIOB, GPIO_Pin_0,  GPIO_Mode_IPU, Bit_RESET, KEY_VALUE_4},
};

KEY_TypeDef UserKEY;


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/* Exported variables --------------------------------------------------------*/
/* Exported function prototypes ----------------------------------------------*/


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void KEY_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    for(uint8_t i = 0; i < KEY_NUMBER; i++)
    {
        RCC_AHBPeriphClockCmd(KEY_GRP[i].RCCn, ENABLE);

        GPIO_StructInit(&GPIO_InitStructure);
        GPIO_InitStructure.GPIO_Pin   = KEY_GRP[i].PINn;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode  = KEY_GRP[i].Mode;
        GPIO_Init(KEY_GRP[i].GPIOn, &GPIO_InitStructure);
    }

    UserKEY.State    = KEY_STATE_IDLE;
    UserKEY.Value    = KEY_VALUE_NULL;
    UserKEY.Type     = KEY_TYPE_SHORT;
    UserKEY.Debounce = 0;
    UserKEY.Interval = 0;
    UserKEY.Trigger  = 0;

    TASK_Append(TASK_ID_KEY, KEY_Scan, 10);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
eKEY_VALUE KEY_Read(void)
{
    for(uint8_t i = 0; i < KEY_NUMBER; i++)
    {
        if(GPIO_ReadInputDataBit(KEY_GRP[i].GPIOn, KEY_GRP[i].PINn) == KEY_GRP[i].Action)
        {
            return KEY_GRP[i].Value;
        }
    }

    return KEY_VALUE_NULL;
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void KEY_Handler(eKEY_VALUE value, eKEY_TYPE type)
{
    if(type == KEY_TYPE_SHORT)
    {
        printf("\r\nShort Click  Key : %d", value);
    }
    else
    {
        printf("\r\nLong Pressed Key : %d", value);
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void KEY_Scan(void)
{
    eKEY_VALUE Value = KEY_Read();

    switch(UserKEY.State)
    {
        case KEY_STATE_IDLE:
            if(Value != KEY_VALUE_NULL)
            {
                if(UserKEY.Debounce++ == 1)
                {
                    UserKEY.State    = KEY_STATE_PRESSED;
                    UserKEY.Value    = Value;
                    UserKEY.Debounce = 0;
                }
            }
            else
            {
                UserKEY.Debounce = 0;
            }
            break;

        case KEY_STATE_PRESSED:
            if(Value == UserKEY.Value)
            {
                if(UserKEY.Debounce++ == 1)
                {
                    UserKEY.State    = KEY_STATE_RELEASE;
                    UserKEY.Debounce = 0;
                    UserKEY.Interval = 100;     /* ��������ʱ�� */
                    UserKEY.Trigger  = 0;
                }
            }
            else
            {
                UserKEY.State    = KEY_STATE_IDLE;
                UserKEY.Debounce = 0;
            }
            break;

        case KEY_STATE_RELEASE:
            if(Value != UserKEY.Value)
            {
                if(UserKEY.Trigger == 0)
                {
                    EVENT_Send(EVENT_TYPE_KEY, UserKEY.Value, KEY_TYPE_SHORT);
                }

                UserKEY.State    = KEY_STATE_IDLE;
                UserKEY.Value    = KEY_VALUE_NULL;
                UserKEY.Debounce = 0;
                UserKEY.Interval = 0;
                UserKEY.Trigger  = 0;
            }
            else
            {
                if(UserKEY.Debounce++ == UserKEY.Interval)
                {
                    EVENT_Send(EVENT_TYPE_KEY, UserKEY.Value, KEY_TYPE_LONG);
                
                    UserKEY.Debounce = 0;
                    UserKEY.Interval = 25;      /* �����ϼ�ʱ�� */
                    UserKEY.Trigger  = 1;
                }
            }
            break;

        default: break;
    }
}


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

