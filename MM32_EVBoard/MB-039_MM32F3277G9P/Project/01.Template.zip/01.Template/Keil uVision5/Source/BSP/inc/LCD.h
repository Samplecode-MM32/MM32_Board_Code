/*******************************************************************************
 * @file    LCD.h
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __LCD_H__
#define __LCD_H__


#ifdef __cplusplus
extern "C" {
#endif


#undef  EXTERN

#ifdef  __LCD_C__
#define EXTERN
#else
#define EXTERN extern
#endif


/* Includes ------------------------------------------------------------------*/
#include "config.h"


/* Exported constants --------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/


/* Exported macro ------------------------------------------------------------*/
#define RGB(r, g, b)    (((uint16_t)(r) << 10) & 0xF800) |  \
                        (((uint16_t)(g) <<  5) & 0x07E0) |  \
                        (((uint16_t)(b) <<  0) & 0x001F)


/* Exported functions --------------------------------------------------------*/
EXTERN void LCD_ClearScreen(uint16_t Color);
EXTERN void LCD_DrawPoint(uint16_t X, uint16_t Y, uint16_t Color);
EXTERN void LCD_Init(void);
EXTERN void LCD_DrawLine(uint16_t StartX, uint16_t StartY, uint16_t EndX, uint16_t EndY, uint16_t Color);
EXTERN void LCD_DrawCircle(uint16_t CenterX, uint16_t CenterY, uint16_t Radius, uint16_t Color, uint8_t Filled);
EXTERN void LCD_DrawRectangle(uint16_t X, uint16_t Y, uint16_t Width, uint16_t Height, uint16_t Color, uint8_t Filled);
EXTERN void LCD_Demo(void);


#ifdef __cplusplus
}
#endif


#endif


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

