/*******************************************************************************
 * @file    LED.h
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __LED_H__
#define __LED_H__


#ifdef __cplusplus
extern "C" {
#endif


#undef  EXTERN

#ifdef  __LED_C__
#define EXTERN
#else
#define EXTERN extern
#endif


/* Includes ------------------------------------------------------------------*/
#include "config.h"


/* Exported constants --------------------------------------------------------*/


/* Exported types ------------------------------------------------------------*/
typedef struct
{
    uint32_t        RCCn;
    GPIO_TypeDef   *GPIOn;
    uint16_t        PINn;
    uint8_t         PinSource;
} LED_TypeDef;


/* Exported macro ------------------------------------------------------------*/


/* Exported functions --------------------------------------------------------*/
EXTERN void LED_Init(void);
EXTERN void LED_Toggle(void);


#ifdef __cplusplus
}
#endif


#endif


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

