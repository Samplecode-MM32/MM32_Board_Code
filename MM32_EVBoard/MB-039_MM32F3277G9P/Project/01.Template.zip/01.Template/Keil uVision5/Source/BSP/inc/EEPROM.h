/*******************************************************************************
 * @file    EEPROM.h
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __EEPROM_H__
#define __EEPROM_H__


#ifdef __cplusplus
extern "C" {
#endif


#undef  EXTERN

#ifdef  __EEPROM_C__
#define EXTERN
#else
#define EXTERN extern
#endif


/* Includes ------------------------------------------------------------------*/
#include "config.h"


/* Exported constants --------------------------------------------------------*/
#define EEPROM_I2C_ADDRESS    0xA0
#define EEPROM_PAGE_SIZE      0x08


/* Exported types ------------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/


/* Exported functions --------------------------------------------------------*/
EXTERN void EEPROM_Init(void);


#ifdef __cplusplus
}
#endif


#endif


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

