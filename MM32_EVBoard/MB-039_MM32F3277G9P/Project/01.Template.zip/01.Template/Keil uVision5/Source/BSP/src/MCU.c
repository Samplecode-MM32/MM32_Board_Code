/*******************************************************************************
 * @file    MCU.c
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#define __MCU_C__


/* Includes ------------------------------------------------------------------*/
#include "MCU.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/


/* Private variables ---------------------------------------------------------*/
uint32_t SysTick_Tick = 0;
uint32_t SysDelayTick = 0;


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/* Exported variables --------------------------------------------------------*/
/* Exported function prototypes ----------------------------------------------*/


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SysTick_Init(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

    if(SysTick_Config(RCC_GetSysClockFreq() / 1000))
    {
        while(1);
    }

    NVIC_SetPriority(SysTick_IRQn, 0);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SysTick_Handler(void)
{
    SysTick_Tick++;
    TASK_TimeSlice(SysTick_Tick);

    if(SysDelayTick)
    {
        SysDelayTick--;
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void SysTick_DelayMS(uint32_t Tick)
{
    SysDelayTick = Tick;
    while(SysDelayTick);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void UART8_SendData(uint8_t Data)
{
    UART_SendData(UART8, Data);
    while(UART_GetFlagStatus(UART8, UART_IT_TXIEN) == RESET);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void UART8_Configure(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOE,    ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2ENR_SYSCFG, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1ENR_UART8,  ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = UART8_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    UART_StructInit(&UART_InitStructure);
    UART_InitStructure.UART_BaudRate            = 115200;
    UART_InitStructure.UART_WordLength          = UART_WordLength_8b;
    UART_InitStructure.UART_StopBits            = UART_StopBits_1;
    UART_InitStructure.UART_Parity              = UART_Parity_No;
    UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;
    UART_InitStructure.UART_Mode                = UART_Mode_Rx | UART_Mode_Tx;
    UART_Init(UART8, &UART_InitStructure);

    UART_ITConfig(UART8, UART_IT_RXIEN, ENABLE);
    UART_Cmd(UART8, ENABLE);

    GPIO_PinAFConfig(GPIOE, GPIO_PinSource0, GPIO_AF_8);
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource1, GPIO_AF_8);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOE, &GPIO_InitStructure);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void UART8_IRQHandler(void)
{
    if(UART_GetITStatus(UART8, UART_IT_RXIEN) != RESET)
    {
        QUEUE_WRITE(QUEUE_UART8_RX_IDX, UART_ReceiveData(UART8));
        UART_ClearITPendingBit(UART8, UART_IT_RXIEN);
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void MCU_PrintInfo(void)
{
    RCC_ClocksTypeDef  RCC_Clocks;
    RCC_GetClocksFreq(&RCC_Clocks);

    printf("\r\n");
    printf("\r\nSYSCLK_Frequency : %d", RCC_Clocks.SYSCLK_Frequency);
    printf("\r\nHCLK_Frequency   : %d", RCC_Clocks.HCLK_Frequency  );
    printf("\r\nPCLK1_Frequency  : %d", RCC_Clocks.PCLK1_Frequency );
    printf("\r\nPCLK2_Frequency  : %d", RCC_Clocks.PCLK2_Frequency );
    printf("\r\n");
    printf("\r\nUID0 : 0x%08x", READ_REG(*((u32 *)(0x1FFFF7E8 + 0))));
    printf("\r\nUID1 : 0x%08x", READ_REG(*((u32 *)(0x1FFFF7E8 + 4))));
    printf("\r\nUID2 : 0x%08x", READ_REG(*((u32 *)(0x1FFFF7E8 + 8))));
    printf("\r\n");
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void MCU_Init(void)
{
    SysTick_Init();

    shellPortInit();

    MCU_PrintInfo();

    UART8_Configure();
}


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

