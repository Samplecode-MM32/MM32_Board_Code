/*******************************************************************************
 * @file    KEY.h
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __KEY_H__
#define __KEY_H__


#undef  EXTERN

#ifdef  __KEY_C__
#define EXTERN
#else
#define EXTERN extern
#endif


/* Includes ------------------------------------------------------------------*/
#include "config.h"


/* Exported constants --------------------------------------------------------*/


/* Exported types ------------------------------------------------------------*/
typedef enum
{
    KEY_VALUE_NULL = 0,
    KEY_VALUE_1,
    KEY_VALUE_2,
    KEY_VALUE_3,
    KEY_VALUE_4,
} eKEY_VALUE;


typedef enum
{
    KEY_STATE_IDLE = 0,
    KEY_STATE_PRESSED,
    KEY_STATE_RELEASE,
} eKEY_STATE;


typedef enum
{
    KEY_TYPE_SHORT = 0,
    KEY_TYPE_LONG,
} eKEY_TYPE;


/* Exported types ------------------------------------------------------------*/
typedef struct
{
    uint32_t            RCCn;
    GPIO_TypeDef       *GPIOn;
    uint16_t            PINn;
    GPIOMode_TypeDef    Mode;
    BitAction           Action;
    eKEY_VALUE          Value;
} KEY_GROUP_TypeDef;


typedef struct
{
    eKEY_STATE State;
    eKEY_VALUE Value;
    eKEY_TYPE  Type;
    uint16_t   Debounce;
    uint16_t   Interval;
    uint8_t    Trigger;
} KEY_TypeDef;


/* Exported macro ------------------------------------------------------------*/


/* Exported functions --------------------------------------------------------*/
EXTERN void KEY_Init(void);
EXTERN void KEY_Scan(void);
EXTERN void KEY_Handler(eKEY_VALUE value, eKEY_TYPE type);


#endif


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

