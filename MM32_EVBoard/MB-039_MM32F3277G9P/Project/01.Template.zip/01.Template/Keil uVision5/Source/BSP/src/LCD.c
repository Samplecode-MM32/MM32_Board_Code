/*******************************************************************************
 * @file    LCD.c
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#define __LCD_C__


/* Includes ------------------------------------------------------------------*/
#include "LCD.h"


/* Private typedef -----------------------------------------------------------*/


/* Private define ------------------------------------------------------------*/
#define BANK1_LCD_CMD   ((uint32_t)0x60000000)
#define BANK1_LCD_DAT   ((uint32_t)0x60080000)


/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/* Exported variables --------------------------------------------------------*/
/* Exported function prototypes ----------------------------------------------*/


/*
 * CS   PD7     AF12    FSMC_NE1
 * RS   PD13    AF12    FSMC_A18
 * WR   PD5     AF12    FSMC_NWE
 * RD   PD4     AF12    FSMC_NOE
 * RST  Connect To MCU  NRST
 * D0   PD14    AF12    FSMC_DA0
 * D1   PD15    AF12    FSMC_DA1
 * D2   PD0     AF12    FSMC_DA2
 * D3   PD1     AF12    FSMC_DA3
 * D4   PE7     AF12    FSMC_DA4
 * D5   PE8     AF12    FSMC_DA5
 * D6   PE9     AF12    FSMC_DA6
 * D7   PE10    AF12    FSMC_DA7
 * D8   PE11    AF12    FSMC_DA8
 * D9   PE12    AF12    FSMC_DA9
 * D10  PE13    AF12    FSMC_DA10
 * D11  PE14    AF12    FSMC_DA11
 * D12  PE15    AF12    FSMC_DA12
 * D13  PD8     AF12    FSMC_DA13
 * D14  PD9     AF12    FSMC_DA14
 * D15  PD10    AF12    FSMC_DA15
 * BL   PF11
 */


#define LCD_BL_H()  GPIO_WriteBit(GPIOF, GPIO_Pin_11, Bit_SET)
#define LCD_BL_L()  GPIO_WriteBit(GPIOF, GPIO_Pin_11, Bit_RESET)


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_InitGPIO(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHBPeriphClockCmd(RCC_AHBENR_GPIOF, ENABLE);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOF, &GPIO_InitStructure);

    LCD_BL_H(); /* Turn On LCD Backlight */
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_HardwareReset(void)
{
#if 0
    LCD_RST_H(); SysTick_DelayMS(10);

    LCD_RST_L(); SysTick_DelayMS(50);

    LCD_RST_H(); SysTick_DelayMS(200);
#endif
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_InitFSMC(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    FSMC_InitTypeDef FSMC_InitStructure;
    FSMC_NORSRAM_Bank_InitTypeDef FSMC_BankInitStructure;

    RCC_AHBPeriphClockCmd( RCC_AHBENR_GPIOD,   ENABLE);
    RCC_AHBPeriphClockCmd( RCC_AHBENR_GPIOE,   ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2ENR_SYSCFG, ENABLE);

    GPIO_PinAFConfig(GPIOD, GPIO_PinSource4,  GPIO_AF_12);  /* FSMC_NOE  */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource5,  GPIO_AF_12);  /* FSMC_NWE  */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource7,  GPIO_AF_12);  /* FSMC_NE1  */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource13, GPIO_AF_12);  /* FSMC_A18  */

    GPIO_PinAFConfig(GPIOD, GPIO_PinSource14, GPIO_AF_12);  /* FSMC_DA0  */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource15, GPIO_AF_12);  /* FSMC_DA1  */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource0,  GPIO_AF_12);  /* FSMC_DA2  */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource1,  GPIO_AF_12);  /* FSMC_DA3  */
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource7,  GPIO_AF_12);  /* FSMC_DA4  */
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource8,  GPIO_AF_12);  /* FSMC_DA5  */
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource9,  GPIO_AF_12);  /* FSMC_DA6  */
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource10, GPIO_AF_12);  /* FSMC_DA7  */
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource11, GPIO_AF_12);  /* FSMC_DA8  */
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource12, GPIO_AF_12);  /* FSMC_DA9  */
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource13, GPIO_AF_12);  /* FSMC_DA10 */
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource14, GPIO_AF_12);  /* FSMC_DA11 */
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource15, GPIO_AF_12);  /* FSMC_DA12 */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource8,  GPIO_AF_12);  /* FSMC_DA13 */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource9,  GPIO_AF_12);  /* FSMC_DA14 */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource10, GPIO_AF_12);  /* FSMC_DA15 */

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_4 | GPIO_Pin_5  | GPIO_Pin_7  |
                                    GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0 | GPIO_Pin_1  | GPIO_Pin_8  |
                                    GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_14 |
                                    GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_7  | GPIO_Pin_8  | GPIO_Pin_9  |
                                    GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 |
                                    GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOE, &GPIO_InitStructure);


    RCC_AHB3PeriphClockCmd(RCC_AHB3ENR_FSMC, ENABLE);

    FSMC_NORSRAM_BankStructInit(&FSMC_BankInitStructure);
    FSMC_BankInitStructure.FSMC_SMReadPipe    = 0;
    FSMC_BankInitStructure.FSMC_ReadyMode     = 0;
    FSMC_BankInitStructure.FSMC_WritePeriod   = 0x2;
    FSMC_BankInitStructure.FSMC_WriteHoldTime = 1;
    FSMC_BankInitStructure.FSMC_AddrSetTime   = 3;
    FSMC_BankInitStructure.FSMC_ReadPeriod    = 0x1;
    FSMC_BankInitStructure.FSMC_DataWidth     = FSMC_DataWidth_16bits;
    FSMC_NORSRAM_Bank_Init(&FSMC_BankInitStructure, FSMC_NORSRAM_BANK0);

    FSMC_NORSRAMStructInit(&FSMC_InitStructure);
    FSMC_InitStructure.FSMC_Mode            = FSMC_Mode_8080;
    FSMC_InitStructure.FSMC_TimingRegSelect = FSMC_TimingRegSelect_0;
    FSMC_InitStructure.FSMC_MemSize         = FSMC_MemSize_64MB;
    FSMC_InitStructure.FSMC_MemType         = FSMC_MemType_NorSRAM;
    FSMC_InitStructure.FSMC_AddrDataMode    = FSMC_AddrDataMUX;
    FSMC_NORSRAMInit(&FSMC_InitStructure);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
uint16_t LCD_RD_DAT(void)
{
    return *(volatile uint16_t *)(BANK1_LCD_DAT);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_WR_CMD(uint16_t Data)
{
    *(volatile uint16_t *)(BANK1_LCD_CMD) = Data;
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_WR_DAT(uint16_t Data)
{
    *(volatile uint16_t *)(BANK1_LCD_DAT) = Data;
}


/*******************************************************************************
 * @brief       ILI9341
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_REG_Configure(void)
{
    LCD_WR_CMD(0xCF);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0xC1);
    LCD_WR_DAT(0X30);
    LCD_WR_CMD(0xED);
    LCD_WR_DAT(0x64);
    LCD_WR_DAT(0x03);
    LCD_WR_DAT(0X12);
    LCD_WR_DAT(0X81);
    LCD_WR_CMD(0xE8);
    LCD_WR_DAT(0x85);
    LCD_WR_DAT(0x10);
    LCD_WR_DAT(0x7A);
    LCD_WR_CMD(0xCB);
    LCD_WR_DAT(0x39);
    LCD_WR_DAT(0x2C);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0x34);
    LCD_WR_DAT(0x02);
    LCD_WR_CMD(0xF7);
    LCD_WR_DAT(0x20);
    LCD_WR_CMD(0xEA);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0x00);
    LCD_WR_CMD(0xC0);
    LCD_WR_DAT(0x1B);
    LCD_WR_CMD(0xC1);
    LCD_WR_DAT(0x01);
    LCD_WR_CMD(0xC5);
    LCD_WR_DAT(0x30);
    LCD_WR_DAT(0x30);
    LCD_WR_CMD(0xC7);
    LCD_WR_DAT(0XB7);
    LCD_WR_CMD(0x36);
    LCD_WR_DAT(0x48);
    LCD_WR_CMD(0x3A);
    LCD_WR_DAT(0x55);
    LCD_WR_CMD(0xB1);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0x1A);
    LCD_WR_CMD(0xB6);
    LCD_WR_DAT(0x0A);
    LCD_WR_DAT(0xA2);
    LCD_WR_CMD(0xF2);
    LCD_WR_DAT(0x00);
    LCD_WR_CMD(0x26);
    LCD_WR_DAT(0x01);
    LCD_WR_CMD(0xE0);
    LCD_WR_DAT(0x0F);
    LCD_WR_DAT(0x2A);
    LCD_WR_DAT(0x28);
    LCD_WR_DAT(0x08);
    LCD_WR_DAT(0x0E);
    LCD_WR_DAT(0x08);
    LCD_WR_DAT(0x54);
    LCD_WR_DAT(0XA9);
    LCD_WR_DAT(0x43);
    LCD_WR_DAT(0x0A);
    LCD_WR_DAT(0x0F);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0x00);
    LCD_WR_CMD(0XE1);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0x15);
    LCD_WR_DAT(0x17);
    LCD_WR_DAT(0x07);
    LCD_WR_DAT(0x11);
    LCD_WR_DAT(0x06);
    LCD_WR_DAT(0x2B);
    LCD_WR_DAT(0x56);
    LCD_WR_DAT(0x3C);
    LCD_WR_DAT(0x05);
    LCD_WR_DAT(0x10);
    LCD_WR_DAT(0x0F);
    LCD_WR_DAT(0x3F);
    LCD_WR_DAT(0x3F);
    LCD_WR_DAT(0x0F);
    LCD_WR_CMD(0x2B);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0x01);
    LCD_WR_DAT(0x3F);
    LCD_WR_CMD(0x2A);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0x00);
    LCD_WR_DAT(0xEF);
    LCD_WR_CMD(0x11);
    SysTick_DelayMS(120);
    LCD_WR_CMD(0x29);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_SetWindow(uint16_t StartX, uint16_t StartY, uint16_t EndX, uint16_t EndY)
{
    LCD_WR_CMD(0x2A);
    LCD_WR_DAT((StartX >> 8) & 0xFF);
    LCD_WR_DAT((StartX >> 0) & 0xFF);
    LCD_WR_DAT((EndX   >> 8) & 0xFF);
    LCD_WR_DAT((EndX   >> 0) & 0xFF);

    LCD_WR_CMD(0x2B);
    LCD_WR_DAT((StartY >> 8) & 0xFF);
    LCD_WR_DAT((StartY >> 0) & 0xFF);
    LCD_WR_DAT((EndY   >> 8) & 0xFF);
    LCD_WR_DAT((EndY   >> 0) & 0xFF);

    LCD_WR_CMD(0x2C);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_ClearScreen(uint16_t Color)
{
    LCD_SetWindow(0, 0, 240, 320);

    for(uint32_t i = 0; i < 240 * 320; i++)
    {
        LCD_WR_DAT(Color);
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_DrawPoint(uint16_t X, uint16_t Y, uint16_t Color)
{
    LCD_SetWindow(X, Y, X, Y);
    LCD_WR_DAT(Color);
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_Init(void)
{
    LCD_InitGPIO();

    LCD_InitFSMC();

    LCD_HardwareReset();

    LCD_REG_Configure();

    LCD_ClearScreen(RGB(255, 0, 0));
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_DrawLine(uint16_t StartX, uint16_t StartY, uint16_t EndX, uint16_t EndY, uint16_t Color)
{
    uint16_t CurrentX = StartX; 
    uint16_t CurrentY = StartY; 

    int16_t  DeltaX = EndX - StartX;
    int16_t  DeltaY = EndY - StartY;

    int16_t  IncreaseX = 0, OffsetX = 0;
    int16_t  IncreaseY = 0, OffsetY = 0;

    uint16_t Distance = 0;

    if(DeltaX > 0)
    {
        IncreaseX = 1;
    }
    else if(DeltaX == 0)
    {
        IncreaseX = 0;
    }
    else
    {
        IncreaseX  =  -1;
        DeltaX = -DeltaX;
    }

    if(DeltaY > 0)
    {
        IncreaseY = 1;
    }
    else if(DeltaY == 0)
    {
        IncreaseY = 0;
    }
    else
    {
        IncreaseY  =  -1;
        DeltaY = -DeltaY;
    }

    if(DeltaX > DeltaY) Distance = DeltaX;
    else                Distance = DeltaY;

    for(uint16_t i = 0; i <= Distance + 1; i++)
    {
        LCD_DrawPoint(CurrentX, CurrentY, Color);

        OffsetX += DeltaX;
        OffsetY += DeltaY;

        if(OffsetX > Distance)
        {
            OffsetX  -= Distance;
            CurrentX += IncreaseX;
        }

        if(OffsetY > Distance)
        {
            OffsetY  -= Distance;
            CurrentY += IncreaseY;
        }
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_DrawCircle(uint16_t CenterX, uint16_t CenterY, uint16_t Radius, uint16_t Color, uint8_t Filled)
{
    int16_t CurrentX = 0, CurrentY = Radius;
    int16_t Distance = 3 - (Radius << 0x01);

    while(CurrentX <= CurrentY)
    {
        if(Filled)
        {
            for(int16_t i = CurrentX; i <= CurrentY; i++)
            {
                LCD_DrawPoint(CenterX + CurrentX, CenterY + i,        Color);
                LCD_DrawPoint(CenterX - CurrentX, CenterY + i,        Color);
                LCD_DrawPoint(CenterX - i,        CenterY + CurrentX, Color);
                LCD_DrawPoint(CenterX - i,        CenterY - CurrentX, Color);
                LCD_DrawPoint(CenterX - CurrentX, CenterY - i,        Color);
                LCD_DrawPoint(CenterX + CurrentX, CenterY - i,        Color);
                LCD_DrawPoint(CenterX + i,        CenterY - CurrentX, Color);
                LCD_DrawPoint(CenterX + i,        CenterY + CurrentX, Color);
            }
        }
        else
        {
            LCD_DrawPoint(CenterX + CurrentX, CenterY + CurrentY, Color);
            LCD_DrawPoint(CenterX - CurrentX, CenterY + CurrentY, Color);
            LCD_DrawPoint(CenterX - CurrentY, CenterY + CurrentX, Color);
            LCD_DrawPoint(CenterX - CurrentY, CenterY - CurrentX, Color);
            LCD_DrawPoint(CenterX - CurrentX, CenterY - CurrentY, Color);
            LCD_DrawPoint(CenterX + CurrentX, CenterY - CurrentY, Color);
            LCD_DrawPoint(CenterX + CurrentY, CenterY - CurrentX, Color);
            LCD_DrawPoint(CenterX + CurrentY, CenterY + CurrentX, Color);
        }

        CurrentX++;

        if(Distance < 0)
        {
            Distance += (4 * CurrentX + 6);
        }
        else
        {
            Distance += (10 + 4 * (CurrentX - CurrentY));
            CurrentY--;
        }
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_DrawRectangle(uint16_t X, uint16_t Y, uint16_t Width, uint16_t Height, uint16_t Color, uint8_t Filled)
{
    if(Filled)
    {
        LCD_SetWindow(X, Y, X+Width, Y+Height);

        for(uint32_t i = 0; i < Width * Height - 1; i++)
        {
            LCD_WR_DAT(Color);
        }
    }
    else
    {
        LCD_DrawLine(X, Y, X+Width,  Y, Color);
        LCD_DrawLine(X, Y, X, Y+Height, Color);
        LCD_DrawLine(X+Width,  Y, X+Width, Y+Height, Color);
        LCD_DrawLine(X, Y+Height, X+Width, Y+Height, Color);
    }
}


/*******************************************************************************
 * @brief       
 * @param       
 * @retval      
 * @attention   
*******************************************************************************/
void LCD_SHELL_Handler(void)
{
    LCD_DrawLine(50, 50, 50,  100, RGB(255, 255, 0));
    LCD_DrawLine(50, 50, 100, 50,  RGB(255, 0, 255));
    LCD_DrawLine(50, 50, 100, 100, RGB(0, 255, 255));

    LCD_DrawRectangle(120, 120, 50, 50, RGB(255, 255, 0), 0);

    LCD_DrawCircle(50,  200, 40, RGB(0, 0, 255), 0);

    LCD_DrawCircle(50,  200, 20, RGB(0, 0, 0), 1);

    LCD_DrawRectangle(140, 240, 20, 20, RGB(255, 255, 0), 1);

    LCD_DrawCircle(150, 250, 40, RGB(255, 0, 255), 0);
}
SHELL_EXPORT_CMD(LCD, LCD_SHELL_Handler, Display Items On LCD Screen);


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

