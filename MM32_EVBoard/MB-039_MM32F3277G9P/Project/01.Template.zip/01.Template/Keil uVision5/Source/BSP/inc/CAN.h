/*******************************************************************************
 * @file    CAN.h
 * @author  King
 * @version V1.00
 * @date    07-June-2021
 * @brief   ......
*******************************************************************************/


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CAN_H__
#define __CAN_H__


#ifdef __cplusplus
extern "C" {
#endif


#undef  EXTERN

#ifdef  __CAN_C__
#define EXTERN
#else
#define EXTERN extern
#endif


/* Includes ------------------------------------------------------------------*/
#include "config.h"


/* Exported constants --------------------------------------------------------*/
#define FRAME_TYPE_DATA             0
#define FRAME_TYPE_REMOTE           1
#define FRAME_TYPE_ERROR            2
#define FRAME_TYPE_OVERLOAD         3

#define FRAME_FORMAT_STANDARD       0
#define FRAME_FORMAT_EXTENDED       1

#define FRAME_ID                    0x100

#define CAN_BAUD_500K               500000
#define CAN_BAUD_250K               250000


/* Exported types ------------------------------------------------------------*/
typedef enum
{
    StandardFrame_SingleFilter = 0,
    ExtendedFrame_SingleFilter = 1,
    StandardFrame_DoubleFilter = 2,
    ExtendedFrame_DoubleFilter = 3,
} CAN_Mode;


/* Exported macro ------------------------------------------------------------*/


/* Exported functions --------------------------------------------------------*/
EXTERN void CAN_Configure(void);
EXTERN void CAN_RxHandler(void);


#ifdef __cplusplus
}
#endif


#endif


/******************* (C) COPYRIGHT 2021 *************************END OF FILE***/

